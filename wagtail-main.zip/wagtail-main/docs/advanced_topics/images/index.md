# Images

```{toctree}
---
maxdepth: 2
---
renditions
animated_gifs
image_file_formats
custom_image_model
changing_rich_text_representation
feature_detection
image_serve_view
focal_points
title_generation_on_upload
```
