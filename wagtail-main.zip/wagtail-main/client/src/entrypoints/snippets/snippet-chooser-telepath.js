import { SnippetChooserFactory } from '../../components/ChooserWidget/SnippetChooserWidget';

window.telepath.register(
  'wagtail.snippets.widgets.SnippetChooser',
  SnippetChooserFactory,
);
