import PageExplorer from './index';

describe('PageExplorer index', () => {
  it('exists', () => {
    expect(PageExplorer).toBeDefined();
  });
});
